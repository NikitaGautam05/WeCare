package backend.backend.service;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import backend.backend.model.Users;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {

    @Value("${security.jwt.secret-key}")
    private String secretKey; // now 32+ chars

    @Value("${security.jwt.expiration-time}")
    private long expirationTime; // e.g., 86400000 for 1 day

    // Helper to get a proper Key object
    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(secretKey.getBytes(StandardCharsets.UTF_8));
    }

    // Generate JWT token
    public String generateToken(Users user) {

        return Jwts.builder()
                .setSubject(
                        (user.getEmail() != null && !user.getEmail().isEmpty())
                                ? user.getEmail()
                                : user.getUserName()
                )
                .claim("role", user.getRole())
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationTime))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }


    // Extract username from token
    public String extractUsername(String token) {
        try {
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(getSigningKey())
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
            return claims.getSubject();
        } catch (JwtException e) {
            // Token is invalid or expired
            return null;
        }
    }

    // Check if token is valid
    public boolean isTokenValid(String token) {
        return extractUsername(token) != null;
    }
}
